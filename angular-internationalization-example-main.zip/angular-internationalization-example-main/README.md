# angular-phrase-example

`npm install` and `npm run start`

## ngx-translate
https://github.com/ngx-translate/core

## phrase
https://app.phrase.com/

## phrase API
https://developers.phrase.com/api/
